package ElementLocators;

import org.openqa.selenium.By;

public class ElementLocators_Rynair {

	public static By LoginMenuOption = By.xpath("/html/body/hp-app-root/hp-home-container/hp-home/hp-header-container/header/hp-header/ry-header/div/div[2]/div/hp-header-menu-item[4]/button/span");
	public static By LoginTab = By.xpath("/html/body/app-root/ry-portal[1]/div/ry-login-signup-dialog/div/ry-login-signup-container/ry-login-signup/ry-login-container/ry-form/div[1]/div[2]");
	//public static By LoginMenuOption = By.className("ry-header__menu-item-title ng-star-inserted");
	public static By LoginField = By.xpath("/html/body/app-root/ry-portal[1]/div/ry-login-signup-dialog/div/ry-login-signup-container/ry-login-signup/ry-login-container/ry-form/div[2]/form/div[1]/ry-input/label/span[2]/input");
	public static By CookiePopup = By.id("//*[contains(@id,'glyphs.close')]");
	//public static By CookiePopup = By.id("glyphs.close");
	//public static By CookiePopup = By.xpath("//svg[@id=\"glyphs.close\" or @viewBox=\"-367 269 64 64\"]");
	public static By PasswordField = By.xpath("/html/body/app-root/ry-portal[1]/div/ry-login-signup-dialog/div/ry-login-signup-container/ry-login-signup/ry-login-container/ry-form/div[2]/form/div[2]/ry-input/label/span[2]/input");
	public static By Btn_Login = By.xpath("/html/body/app-root/ry-portal[1]/div/ry-login-signup-dialog/div/ry-login-signup-container/ry-login-signup/ry-login-container/ry-form/div[2]/form/div[6]/button");
	
    
	public static By OnewayTraveloption = By.xpath("//label[contains(text(),'One way')]");
	public static By FromTravel = By.xpath("//input[@id='input-button__departure']");
	public static By ToTravel = By.xpath("//input[@id='input-button__destination']");
	public static By FlightSearchBtn = By.xpath("//button[@class='flight-search-widget__start-search ry-button--gradient-yellow ng-trigger ng-trigger-collapseExpandCta']");
	public static By ChooseDatebtn = By.xpath("/html/body/hp-app-root/hp-home-container/hp-home/hp-search-widget/div/hp-flight-search-widget-container/hp-flight-search-widget/div[1]/hp-flight-search-widget-controls-container/hp-flight-search-widget-controls/div[2]/div/hp-input-button[1]/div/div[2]");
	//public static By CalendarControl = By.xpath("//calendar[@class='datepicker__calendar datepicker__calendar--left']//div[@class='calendar-body__cell'][contains(text(),'\"+day+\"')]");
	//public static By ChooseDatebtn =By.className("flight-widget-controls__control flight-widget-controls__control--date ng-trigger ng-trigger-datesFromTripTypeChange");
	
	public static By FlightPriceSelectOption = By.xpath("/html/body/flights-root/div/flights-summary-container/flights-summary/div/div[1]/journey-container/journey/flight-list/div/flight-card/div/button/div[3]/flight-price/div/span[2]");
	public static By Btn_ContinuewithValueFare = By.xpath("/html/body/flights-root/div/flights-summary-container/flights-summary/div/div[1]/journey-container/journey/flight-list/div/flight-card/div/div/fare-table-container/fare-table/div/div[1]/fare-card/div/div/button");
	//public static By PassengerTitleDropdownList = By.xpath("/html/body/flights-root/div/flights-lazy-passengers/pax-app-container/pax-app/ry-spinner/div/div/div[2]/pax-app-form-container/pax-app-form/form/pax-passenger-container/pax-passenger/div/pax-passenger-details-container/pax-passenger-details/pax-passenger-details-form-container/pax-details-form/ry-dropdown/div[2]/button");
	public static By PassengerTitleDropdownList = By.xpath("//*[@class='dropdown__toggle b2' and @type='button']");
	public static By ChoosePassengerListItem = By.className("dropdown-item__label b2");
	public static By txt_FirstName = By.id("formState.passengers.ADT-0.name");
	public static By txt_LastName = By.id("formState.passengers.ADT-0.surname");
	public static By Btn_Passengers_Continue = By.xpath("//button[contains(text(),\"Continue\")]");
	//public static By ListItemMr = By.xpath("//div[@class='dropdown-item__label b2' and text()='Mr']");   //Dynamic xpath
	public static By ListItemMr = By.xpath("//*[contains(text(),'Mr')]");	
	public static By ListItemMrs = By.xpath("//button[@class='dropdown__toggle b2']//following::div[2]/ry-dropdown-item/button/div[2][contains(text(),'Mrs')]");  //Dynamic xpath
	public static By ListItemMs = By.xpath("//*[contains(text(),'Ms')]");    //Dynamic xpath
	public static By Btn_SeatConfirmationContinue = By.xpath("/html/body/seats-root/div/main/seats-container/div/div[3]/div[2]/div/seats-actions/span[2]/button");
	public static By Btn_FinalSeatConfirmationContinue = By.xpath("/html/body/seats-root/ry-portal[1]/div/seats-modal/ry-message-dialog/ry-dialog/div/div[2]/div[2]/button[1]");

   public static By BaggageItemSelectionOption = By.xpath("/html/body/bags-root/bags-app-container/div/main/div/ry-spinner/section[1]/bags-cabin-bag/bags-bag-layout/div/div/div[2]/bags-cabin-bag-journey-container/bags-cabin-bag-row/bags-cabin-bag-products-container/bags-cabin-bag-product[2]/div/ry-checkbox/label/div/div[1]");
   public static By Btn_BagItem_Continue = By.xpath("//button[@class='ry-button--gradient-yellow']");
   
   
   public static By Btn_AnythingElseContinue = By.xpath("//button[@class='ry-button--full ry-button--gradient-yellow ry-button--large']");
   
   public static By FlightBasketPopup = By.xpath("/html/body/app-root/ry-spinner/div/trip-header-wrapper/header/ry-header/div/div[3]/div[2]/ry-tooltip/div[2]/trip-basket-tooltip/div/trip-tooltip-template/icon[2]/span/svg");
   
   
   //public static By ViewBasket =By.xpath("/html/body/app-root/ry-spinner/div/trip-header-wrapper/header/ry-header/div/div[3]/div[2]/ry-tooltip/div[2]/trip-basket-tooltip/div/div/a[2]");
   public static By ViewBasket =By.xpath("/html/body/app-root/ry-spinner/div/trip-header-wrapper/header/ry-header/div/div[3]/div/ry-tooltip/div[2]/trip-basket-tooltip/div/div/a[2]");
   
   public static By AddCartOption = By.xpath("/html/body/app-root/ry-spinner/div/trip-header-wrapper/header/ry-header/div/div[3]/div[2]/ng-component/ry-basket-total-container/ry-basket-total/div/div/div[2]/span");
   
   public static By Btn_Checkout = By.xpath("//button[@class='ry-button--full ry-button--gradient-yellow']");
   //public static By SelectCountryCodeList = By.id("countries");
   public static By SelectCountryCodeList = By.tagName("option");
   
   public static By txt_Mobileno = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[1]/contact-details/div/div/div[1]/ry-input[2]/label/span[2]/input");
   
   public static By InsuredLabel = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[2]/insurance/div/div[2]/div/div/div[1]/div/strong");
   public static By InsuredOption = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[2]/insurance/div/div[2]/div/div/div[2]/ry-checkbox/label/div/div[1]");
   
   public static By PaymentbycardOption = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/div/ry-checkbox/label/div/div[1]");
   
   public static By txt_CardNumber = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[1]/div/card-details/form/ry-input[1]/label/span[2]/input");
   public static By txt_cardExpiryDate = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[1]/div/card-details/form/expiry-date/label/span[2]/input");
   public static By txt_SecurityCode = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[1]/div/card-details/form/verification-code/div/ry-input/label/span[2]/input");
   public static By txt_CardHolderName = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[1]/div/card-details/form/ry-input[2]/label/span[2]/input");
   public static By SelectCurrencyfromList = By.tagName("option");
   
   public static By txt_AddressLine01 = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[2]/billing-address/address-form/form/ry-input[1]/label/span[2]/input");
   public static By txt_AddressLine02 = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[2]/billing-address/address-form/form/ry-input[2]/label/span[2]/input");
   public static By txt_CityName = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[2]/billing-address/address-form/form/ry-input[3]/label/span[2]/input");
   
   public static By SelectCountryMainList = By.tagName("option");
   public static By txt_PostalCode = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/div/add-method-modal/form/div/div/div[2]/billing-address/address-form/form/ry-input[4]/label/span[2]/input");
   
   public static By CheckPayoption = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[8]/div/terms-and-conditions/div/div/ry-checkbox/label/div/div[1]");
   public static By btn_PayNow = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[8]/div/pay-button/div/button");
   
   public static By ErrorMessage = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[5]/payment-methods/div/div/div[1]/ry-alert/div/div/div");
   //button[@class='ry-button--full ry-button--gradient-yellow ry-button--large']
   
 //button[@class='ry-button--full ry-button--gradient-yellow ry-button--large']
  public static By DummyScroll = By.xpath("/html/body/hp-app-root/hp-home-container/hp-home/hp-lazy-content/hp-content-container/hp-content/section[5]/hp-explore-like-pro-container/hp-explore-like-pro/div/a[2]");
  public static By ErrorAlertMessageBox = By.xpath("/html/body/app-root/ng-component/ry-spinner/div/payment-form/form/div[10]/div[1]/div/div[1]/div/icon/span/svg/path");


}
