package PageFactory;

import java.awt.AWTException;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryResuableComp {
	
	static WebDriver driver;
	static JavascriptExecutor js = (JavascriptExecutor)driver;

	public static void openbrowser(String url) {
		
		System.setProperty("webdriver.chrome.driver","D:\\RYN\\POMJAVAExample-master\\com.ryanair.com\\lib\\chromedriver.exe");
	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(url);
		System.out.println("Browser Opened");
		driver.manage().window().maximize();
	}

	
	public static void SendValue(String val,By locator) throws InterruptedException {
		
		WebElement ele = driver.findElement(locator);
		System.out.println("Sending Text");
		Thread.sleep(20);
		ele.clear();
		ele.sendKeys("");
		Thread.sleep(05);
		ele.sendKeys(val);
	}	
	
	
 public static void clickMethod(By locatorforclick) throws InterruptedException {
		
		System.out.println("Clicking a Button");
		driver.findElement(locatorforclick).click();
		Thread.sleep(5000);
	}	
 
 public static void close() {
	 System.out.println("Closing the Browser");
	 driver.close();
	 
	 System.out.println("Automation Process Completed...");
 }
	


 public static void takeSnapShot(String fileWithPath) throws Exception{

	 File srcFile= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	 try {
	  // now copy the  screenshot to desired location using copyFile //method
	 FileUtils.copyFile(srcFile, new File(fileWithPath));
	 }
	  
	 catch (IOException e)
	  {
	   System.out.println(e.getMessage());
	  
	  } }
 
 
 
 
 
 
 public static String configFileReader() throws IOException {
	 Properties prop = new Properties();
	 
     //Read configuration.properties file
     try {
         prop.load(new FileInputStream("D:\\RYN\\POMJAVAExample-master\\com.ryanair.com\\src\\test\\java\\EnvironmentDetails\\Environment.properties"));
         //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
     } catch (IOException e) {
         System.out.println("Configuration properties file cannot be found");
     }

     //Get properties from configuration.properties
     //url = prop.getProperty("url");
     String ScreenshotPath = prop.getProperty("ScreenshotPath");
    // String LoginId = prop.getProperty("LoginId");
    // String Password = prop.getProperty("Password");
     //wrongPassword = prop.getProperty("wrongPassword");
     return ScreenshotPath;
 }


 
 
 public static void WaitForPageLoad(int getPageloadTime)  {
		
	
	 driver.manage().timeouts().pageLoadTimeout(getPageloadTime, TimeUnit.SECONDS);
	
 }	


 public static void WebclickByScript(By locatorforclick1)  {
		
		
	 js.executeScript("arguments[0].click();", locatorforclick1);
	 
	
 }	

 public static void WaittimeSeconds(int Timeseconds) throws InterruptedException  {
		
		
	  Thread.sleep(Timeseconds*1000);
	 
	
 }	

 
 public static void AlertDismiss() throws InterruptedException  {
		
		
	 Alert alert = driver.switchTo().alert();
	 alert.dismiss();
	 
	 
	
}	
 
 
 
 public static void WindowHandlesforPopup(By PopupElementID) throws InterruptedException  {
		
		
	 for (String winhandle: driver.getWindowHandles()) {
		    driver.switchTo().window(winhandle);
		    //System.out.println("Window Switch");        
		    Thread.sleep(2000);

		    driver.findElement(PopupElementID).click();
		}
	 
	 
	
}	

 
 
 public static void SelectDayFromMultiDateCalendar(String day)
			throws InterruptedException {

	 //String Mycalender = CalendarControl.toString();
	 
	 //Mycalender.replace("day", day);
		
		By calendarXpath = By.xpath("//calendar[@class='datepicker__calendar datepicker__calendar--left']//div[@class='calendar-body__cell'][contains(text(),'"+day+"')]");
		driver.findElement(calendarXpath).click();

		// Intentional pause for 2 seconds.
		Thread.sleep(2000);
	}
 
 
 public static void MousehoverAndClick(By locators) throws InterruptedException  {
		
		
	 Actions action = new Actions(driver);
	 WebElement we = driver.findElement(locators);
	 action.moveToElement(we).click().build().perform();
	 
	
}	
 
 
 
 public static void Mousehover(By Mouselocators) throws InterruptedException  {
		
		
	 Actions action = new Actions(driver);
	 WebElement we = driver.findElement(Mouselocators);
	 action.moveToElement(we).build().perform();
	 
	
}	
 
 
 
 public static void WebScrollDown() throws InterruptedException  {
		
		
	 //js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	 Robot robot = null;
	try {
		robot = new Robot();
	} catch (AWTException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 robot.keyPress(KeyEvent.VK_PAGE_DOWN);
	 robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
	 
	
}	
 
 
 
 
 public static void WebScrolltoElement(By ElementId) throws InterruptedException  {
		
		
	 WebElement elements = driver.findElement(ElementId);
	 //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elements);
	 //Thread.sleep(500); 
	 
	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true); window.scrollBy(0,-100);", elements); 
	  //element.click()`;
	 
	
}	
 
 
 
 
 
 
 
 public static void SelectValuefromList(By ListLocator,String ListCountryValue) throws InterruptedException  {
		
	 /**
	 
	 WebElement country= driver.findElement(ListLocator);
	 
	 Select Maincountrycode=new Select(country);
	 
	 Maincountrycode.selectByVisibleText(ListCountryValue);
	
**/
	 
	 List<WebElement> options= driver.findElements(ListLocator);
	 
	 for (WebElement option : options) {

		 if(ListCountryValue.equals(option.getText()))

		  option.click();   
		 }
	 
	 
	 

}
 
 
 public static void SelectCurrencyfromList(By CurrencyListLocator,String ListCurrency) throws InterruptedException  {
		
	 /**
	 
	 WebElement country= driver.findElement(ListLocator);
	 
	 Select Maincountrycode=new Select(country);
	 
	 Maincountrycode.selectByVisibleText(ListCountryValue);
	
**/
	 
	 List<WebElement> options= driver.findElements(CurrencyListLocator);
	 
	 
	 /**
	 for (WebElement option : options) {

		 if(ListCurrency.equals(option.getText().trim()))

		  option.click();   
		 }
		 
		 **/
	 
	 
	 
	 for (WebElement option : options) {

		 if(option.getText().trim().startsWith(ListCurrency))

		  option.click();   
		 
	 }
	 
	 

}

 
 
 
 public static void UsercontrolforDropDownlist() throws InterruptedException  {
		
	 JFrame frame = new JFrame("User Control");
	JOptionPane.showMessageDialog(frame, "Please selech User title from the drop down list and click OK button");
	
}
 
 
 
 public static void UsercontrolforCloseCookieSetting() throws InterruptedException  {
		
	 JFrame frame = new JFrame("User Control");
	JOptionPane.showMessageDialog(frame, "Please click the cancel option of cookie pop up screen and click OK button");
	//Thread.sleep(30);
}
 
 
 
 
 public static void slowEntering(By ElementIdd,String SlowValue) throws InterruptedException {
		
	 WebElement Slowelements = driver.findElement(ElementIdd);
	
	 char[] ch=SlowValue.toCharArray();    
	 for(int i=0; i<ch.length;i++){  
		 
		 
	        //CharSequence[] c = CardExpiryDate.charAt(i);  
	       // System.out.println("char at "+i+" index is: "+c);  
		Slowelements.sendKeys(ch[i]+"");
		// Slowelements.
	        Thread.sleep(20);
	 }
	
 }
 
 
 
 
 
 
 
}
