package TestData;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestDataHandlerold {
	
	private static String LoginIDs;
	
	public void testDataReader() {
	  
	
	//InputStream is = null;
    //Properties prop = null;
   Properties prop = new Properties();
    try {
       // prop = new Properties();
       // is = new FileInputStream(new File("D:\\RYN\\POMJAVAExample-master\\com.ryanair.com\\src\\test\\java\\TestData\\Testdata.properties"));
       // prop.load(is);
        
        prop.load(new FileInputStream("D:\\RYN\\POMJAVAExample-master\\com.ryanair.com\\src\\test\\java\\TestData\\Testdata.properties"));
       // LoginIDs = prop.getProperty("LoginId");
       //prop.getProperty("db.user");
      // prop.getProperty("db.password");
    } catch (FileNotFoundException e1) {
        e1.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
	
    LoginIDs = prop.getProperty("LoginId");
	
	
	}

	public String getLoginID() {
		return LoginIDs;
	}

	public void setLoginID(String LoginIDs) {
		TestDataHandlerold.LoginIDs = LoginIDs;
	}
	
	
	


}
    




