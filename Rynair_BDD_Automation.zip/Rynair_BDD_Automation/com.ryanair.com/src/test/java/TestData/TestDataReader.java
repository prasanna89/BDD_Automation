package TestData;

import java.util.Random;

public class TestDataReader {


	
	private String URL= "https://www.ryanair.com/ie/en/";
	String LoginId= "xxxxx@gmail.com";   //Please create a new Login for Automation with Rynair Application
	String Password= "xxxxxxx";       //Please create a new Password for Automation with Rynair Application
	String FromTravel = "Warsaw Modlin";
	String ToTravel = "Oslo Torp";
	//private String getRandomChar;
	//String TitleValuefromDropdownList =""
	String PricePage_PassengerFirstName = "PassengerFirstName"+String.valueOf(getRandomChar());
	String PricePage_PassengerLastName = "PassengerLastName"+String.valueOf(getRandomChar());
	
	String Mobileno = "9842451115";
	
	String CardNumber = "5555 5555 5555 5557";
	String CardExpiryDate = "1020";
	String Securitycode = "265";
	String CardholderName = "HolderName"+String.valueOf(getRandomChar());
	String Address01 = " First AdreessLine"+ String.valueOf(getRandomChar());
	String Address02 = " Second AdreessLine"+ String.valueOf(getRandomChar());
	String City = "Chennai"+String.valueOf(getRandomChar());
	String Pincode = "600059";
	String PaymentDeclineMessage = "Transaction could not be processed. Your payment was not authorised therefore we could not complete your booking. Please ensure that the information was correct and try again or use a new payment card.";
	
	
	
	
	
	
	public String getPincode() {
		return Pincode;
	}

	public void setPincode(String Pincode) {
		this.Pincode = Pincode;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}

	public String getAddress02() {
		return Address02;
	}

	public void setAddress02(String Address02) {
		this.Address02 = Address02;
	}

	public String getAddress01() {
		return Address01;
	}

	public void setAddress01(String Address01) {
		this.Address01 = Address01;
	}

	public String getCardholderName() {
		return CardholderName;
	}

	public void setCardholderName(String CardholderName) {
		this.CardholderName = CardholderName;
	}

	public String getSecuritycode() {
		return Securitycode;
	}

	public void setSecuritycode(String Securitycode) {
		this.Securitycode = Securitycode;
	}

	public String getCardExpiryDate() {
		return CardExpiryDate;
	}

	public void setCardExpiryDate(String CardExpiryDate) {
		this.CardExpiryDate = CardExpiryDate;
	}

	public String getCardNumber() {
		return CardNumber;
	}

	public void setCardNumber(String CardNumber) {
		this.CardNumber = CardNumber;
	}
	
	

	public String getMobileno() {
		return Mobileno;
	}

	public void setMobileno(String Mobileno) {
		this.Mobileno = Mobileno;
	}
	
	

	public String getPricePage_PassengerLastName() {
		return PricePage_PassengerLastName;
	}

	public void setPricePage_PassengerLastName(String pricePage_PassengerLastName) {
		this.PricePage_PassengerLastName = pricePage_PassengerLastName;
	}

	public String getPricePage_PassengerFirstName() {
		return PricePage_PassengerFirstName;
	}

	public void setPricePage_PassengerFirstName(String pricePage_PassengerFirstName) {
		this.PricePage_PassengerFirstName = pricePage_PassengerFirstName;
	}

	
	public String getToTravel() {
		return ToTravel;
	}

	public void setToTravel(String toTravel) {
		this.ToTravel = toTravel;
	}

	public String getFromTravel() {
		return FromTravel;
	}
	
	public void setFromTravel(String fromTravel) {
		this.FromTravel = fromTravel;
	}
	
		
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		this.URL = uRL;
	}
	
	public String getLoginId() {
		return LoginId;
	}
	public void getLoginId(String LoginId) {
		this.LoginId = LoginId;
	}
	
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String Password) {
		this.Password = Password;
	}
	
	

	
	
	
	
	// Generate random Numbers
	/**
	public int getRandomNo() {
	int random = (int)(Math.random() * 50 + 1);
    return random;
}

**/
	
	
	public char getRandomChar() {
		Random r = new Random();
		char c = (char)(r.nextInt(26) + 'a');
		return c;
	}

}
