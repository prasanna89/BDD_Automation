package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import ElementLocators.ElementLocators_Rynair;
import PageFactory.PageFactoryResuableComp;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Test;
import PageFactory.PageFactoryResuableComp;
import TestData.TestDataReader;
//import TestData.TestDataHandler.*;

@SuppressWarnings("unused")
public class StepDef_Rynair {

	TestDataReader TDH = new TestDataReader();
	//private static final WebDriver driver = null;
	//PageFactory.PageFactoryResuableComp.
	String ScreenshotName = null;
	//String Loginname = TDH.getLogin();
	//String SignInValue = TDH.testdataReader()

	
	
	
	
	@Given("^open website Rynair$")
	public void open_website_Rynair() throws Throwable {
	
	ScreenshotName = "I want to open website Rynair";
	System.out.println("Welcome to Rynair Website");
	  
	 String Tempstr = TDH.getURL();
	 
	PageFactoryResuableComp.openbrowser(Tempstr);
		
	PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	}

	
	
	@Then("^wait for page load time \"([^\"]*)\"$")
	public void wait_for_page_load_time(String loadtime) throws Throwable {
		int PageLoadtime = Integer.parseInt(loadtime);
		PageFactoryResuableComp.WaitForPageLoad(PageLoadtime);
	
	}
	
	
	
	@When("^I click menu option \"([^\"]*)\"$")
	public void i_click_menu_option(String MenuOption) throws Throwable {
		
		ScreenshotName = "I click menu option"+"  "+MenuOption;
		
		if(MenuOption.equalsIgnoreCase("LoginMenuOption")) {
			
			PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.LoginMenuOption);
		    
		   } 
	
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	
	
	
	
	}

	
	/**
	
	@When("^click on element \"([^\"]*)\" by script$")
	public void click_on_element_by_script(String MenuOption) throws Throwable {
   
		  if(MenuOption.equalsIgnoreCase("LoginMenuOption")) {
			
			PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.LoginMenuOption);
		    
		   } 
		  
		  
		  if(MenuOption.equalsIgnoreCase("ChooseDatebtn")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.ChooseDatebtn);
			    
			   } 
		  
		  
		  if(MenuOption.equalsIgnoreCase("ListItemMr")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.ListItemMr);
			    
			   } 
	
	
	
	
	}

	**/
	
	
	
	@When("^click on element \"([^\"]*)\" by script$")
	public void click_on_element_by_script(String MenuOption) throws Throwable {
		
		
		ScreenshotName = "click on element"+"  "+MenuOption+"  "+"by script";
   
		  if(MenuOption.equalsIgnoreCase("ListItemMr")) {
			
			PageFactoryResuableComp.WebclickByScript(ElementLocators_Rynair.ListItemMr);
		    
		   } 
		  
		  
		  if(MenuOption.equalsIgnoreCase("ListItemMrs")) {
				
				PageFactoryResuableComp.WebclickByScript(ElementLocators_Rynair.ListItemMrs);
			    
			   } 
		  
		  
		  if(MenuOption.equalsIgnoreCase("ListItemMs")) {
				
				PageFactoryResuableComp.WebclickByScript(ElementLocators_Rynair.ListItemMs);
			    
			   } 
		  
		  if(MenuOption.equalsIgnoreCase("LoginMenuOption")) {
				
				PageFactoryResuableComp.WebclickByScript(ElementLocators_Rynair.LoginMenuOption);
			    
			   } 
	
		  PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	}
	
	
	
	
	
	@Then("^list generate user control$")
	public void list_generate_user_control() throws Throwable {
   
		ScreenshotName = "list generate user control";
		System.out.println("list User Control has Initiated..");
		PageFactoryResuableComp.UsercontrolforDropDownlist();
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	}
	
	
	
	@Then("^cookie generate user control$")
	public void cookie_generate_user_control() throws Throwable {
   
		ScreenshotName = "cookie generate user control";
		System.out.println("cookie User Control has Initiated..");
		PageFactoryResuableComp.UsercontrolforCloseCookieSetting();
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	}
	
	
	
	
	@Then("^validate card payment declined action$")
	public void validate_card_payment_declined() throws Throwable {
   
		ScreenshotName = "validate card payment declined action";
		
		if(ElementLocators_Rynair.ErrorMessage!=null)
		{
			System.out.println("The card payment has declined during to incorrect card details");
		}
	
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	}
	
	
	
	
	
	@Then("^I should wait for \"([^\"]*)\" seconds$")
	public void I_should_wait_for(String Timeseconds) throws Throwable {
   
		  
		int Timeseconds1 = Integer.parseInt(Timeseconds);
		PageFactoryResuableComp.WaittimeSeconds(Timeseconds1);
	}

	
	
	
	@When("^choose day \"([^\"]*)\" from the month$")
	public void choose_day(String dayofMonth) throws Throwable {
   
		ScreenshotName = "choose day"+"  "+dayofMonth+"  "+"from the month"; 
		//int Timeseconds1 = Integer.parseInt(Timeseconds);
		PageFactoryResuableComp.SelectDayFromMultiDateCalendar(dayofMonth);
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	}

	
	
	@When("^select value \"([^\"]*)\" from the drop down list \"([^\"]*)\"$")
	public void select_value_fromdropdownlist(String Selectvalue,String ListElementID) throws Throwable {
   
		ScreenshotName = "select value "+"  "+Selectvalue+"  "+" from the drop down list"+"  "+ListElementID;
		
		/**
		  
		if(Selectvalue.equalsIgnoreCase("Mr")&& ListElementID.equalsIgnoreCase("ChoosePassengerListItem")) {
			
			
		PageFactoryResuableComp.SelectValuefromList(ElementLocators_Rynair.ChoosePassengerListItem,Selectvalue);
		
	
		}
		
		
		if(Selectvalue.equalsIgnoreCase("Mrs")&& ListElementID.equalsIgnoreCase("ChoosePassengerListItem")) {
			
			
			PageFactoryResuableComp.SelectValuefromList(ElementLocators_Rynair.ChoosePassengerListItem,Selectvalue);
			
		
			}
		
		
		if(Selectvalue.equalsIgnoreCase("Ms")&& ListElementID.equalsIgnoreCase("ChoosePassengerListItem")) {
			
			
			PageFactoryResuableComp.SelectValuefromList(ElementLocators_Rynair.ChoosePassengerListItem,Selectvalue);
			
		
			}
		
		
	   **/
		
		
		 if(Selectvalue.equalsIgnoreCase(" India (+91) ")&& ListElementID.equalsIgnoreCase("SelectCountryCodeList")) {
			
			
			PageFactoryResuableComp.SelectValuefromList(ElementLocators_Rynair.SelectCountryCodeList,Selectvalue);
			
		
			}
		 
		 
		 if(Selectvalue.equalsIgnoreCase(" India ")&& ListElementID.equalsIgnoreCase("SelectCountryMainList")) {
				
				
				PageFactoryResuableComp.SelectValuefromList(ElementLocators_Rynair.SelectCountryCodeList,Selectvalue);
				
			
				}
		

    PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
	}

	
	
	
	
	
	
	@When("^perform select currency \"([^\"]*)\" from the drop down list \"([^\"]*)\"$")
	public void perform_select_currency(String SelectCurrencyValue,String CurrencyListElementID) throws Throwable {
   
		ScreenshotName = "perform select currency "+"  "+SelectCurrencyValue+"  "+" from the drop down list "+"  "+CurrencyListElementID;
		
		 if(SelectCurrencyValue.equalsIgnoreCase("PLN")&& CurrencyListElementID.equalsIgnoreCase("SelectCurrencyfromList")) {
			
			
			PageFactoryResuableComp.SelectCurrencyfromList(ElementLocators_Rynair.SelectCurrencyfromList,SelectCurrencyValue);
			
		
			}
		 
		 PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
		 
		
	
	
	}

	
	
	
	
	@Then("^make click button \"([^\"]*)\"$")
	public void make_click_button(String UserButton) throws Throwable {
		
		ScreenshotName = "make click button "+"  "+UserButton;
		
		  String btn_Click = UserButton;
		
		  if(UserButton.equalsIgnoreCase("Btn_Login")) {
			
			PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_Login);
			//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
		     } 
		
		  
		  if(UserButton.equalsIgnoreCase("CookiePopup")) {
			  
			  try {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.CookiePopup);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
				
			     
			  }
			  
			  catch(Exception ex) {
				  
				  PageFactoryResuableComp.UsercontrolforCloseCookieSetting();
				  
			  }
		  
		  
		  
		  
		  } 
		  
		  
		  
		  
		  
		  
		  if(UserButton.equalsIgnoreCase("OnewayTraveloption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.OnewayTraveloption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  
		  if(UserButton.equalsIgnoreCase("FlightSearchBtn")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.FlightSearchBtn);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  /**
		  if(UserButton.equalsIgnoreCase("ChooseDatebtn")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.ChooseDatebtn);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		 **/
		  
		  
		  if(UserButton.equalsIgnoreCase("FlightPriceSelectOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.FlightPriceSelectOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  
		  if(UserButton.equalsIgnoreCase("Btn_ContinuewithValueFare")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_ContinuewithValueFare);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  if(UserButton.equalsIgnoreCase("PassengerTitleDropdownList")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.PassengerTitleDropdownList);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  if(UserButton.equalsIgnoreCase("Btn_Passengers_Continue")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_Passengers_Continue);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  if(UserButton.equalsIgnoreCase("PassengerTitleDropdownList")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.PassengerTitleDropdownList);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  if(UserButton.equalsIgnoreCase("ListItemMr")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.ListItemMr);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  
		  if(UserButton.equalsIgnoreCase("Btn_SeatConfirmationContinue")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_SeatConfirmationContinue);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  

		  if(UserButton.equalsIgnoreCase("Btn_FinalSeatConfirmationContinue")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_FinalSeatConfirmationContinue);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  
		  if(UserButton.equalsIgnoreCase("BaggageItemSelectionOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.BaggageItemSelectionOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  if(UserButton.equalsIgnoreCase("Btn_BagItem_Continue")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_BagItem_Continue);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  if(UserButton.equalsIgnoreCase("Btn_AnythingElseContinue")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_AnythingElseContinue);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		    if(UserButton.equalsIgnoreCase("FlightBasketPopup")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.FlightBasketPopup);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		    
		    
           if(UserButton.equalsIgnoreCase("AddCartOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.AddCartOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
           
           if(UserButton.equalsIgnoreCase("Btn_Checkout")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_Checkout);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("PaymentbycardOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.PaymentbycardOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("CheckPayoption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.CheckPayoption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("btn_PayNow")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.btn_PayNow);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("InsuredOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.InsuredOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("LoginTab")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.LoginTab);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           
           if(UserButton.equalsIgnoreCase("LoginMenuOption")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.LoginMenuOption);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
           
           if(UserButton.equalsIgnoreCase("ViewBasket")) {
				
				PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.ViewBasket);
				//PageFactoryResuableComp.clickMethod(ElementLocators_Rynair);
			     }
		  
		  
		  
           PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
		  
		  
	}
	
	
	
	
	@Then("^enter data in the field \"([^\"]*)\"$")
	public void enter_data_in_the_field(String FieldData) throws Throwable {
		
		ScreenshotName = "enter data in the field  "+"  "+FieldData;
		if(FieldData.equalsIgnoreCase("LoginField")) {
			
		    PageFactoryResuableComp.SendValue(TDH.getLoginId(),ElementLocators_Rynair.LoginField);
		    
		     } 
			
			
			if(FieldData.equalsIgnoreCase("PasswordField")) {
				
			    PageFactoryResuableComp.SendValue(TDH.getPassword(),ElementLocators_Rynair.PasswordField);
			    
			    } 
			
			
              if(FieldData.equalsIgnoreCase("FromTravel")) {
				
			    PageFactoryResuableComp.SendValue(TDH.getFromTravel(),ElementLocators_Rynair.FromTravel);
			    
			    } 
              
              
              if(FieldData.equalsIgnoreCase("ToTravel")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getToTravel(),ElementLocators_Rynair.ToTravel);
  			    
  			    } 
              
              
              if(FieldData.equalsIgnoreCase("txt_FirstName")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getPricePage_PassengerFirstName(),ElementLocators_Rynair.txt_FirstName);
    			    
    			    } 
              
              
              if(FieldData.equalsIgnoreCase("txt_LastName")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getPricePage_PassengerLastName(),ElementLocators_Rynair.txt_LastName);
    			    
    			    } 
              
              
              if(FieldData.equalsIgnoreCase("txt_Mobileno")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getMobileno(),ElementLocators_Rynair.txt_Mobileno);
  			    
  			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_CardNumber")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getCardNumber(),ElementLocators_Rynair.txt_CardNumber);
    			    
    			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_cardExpiryDate")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getCardExpiryDate(),ElementLocators_Rynair.txt_cardExpiryDate);
  			    
  			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_SecurityCode")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getSecuritycode(),ElementLocators_Rynair.txt_SecurityCode);
    			    
    			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_CardHolderName")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getCardholderName(),ElementLocators_Rynair.txt_CardHolderName);
  			    
  			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_AddressLine01")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getAddress01(),ElementLocators_Rynair.txt_AddressLine01);
    			    
    			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_AddressLine02")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getAddress02(),ElementLocators_Rynair.txt_AddressLine02);
  			    
  			    }
              
              
              if(FieldData.equalsIgnoreCase("txt_CityName")) {
    				
    			    PageFactoryResuableComp.SendValue(TDH.getCity(),ElementLocators_Rynair.txt_CityName);
    			    
    			    }
              
              if(FieldData.equalsIgnoreCase("txt_PostalCode")) {
  				
  			    PageFactoryResuableComp.SendValue(TDH.getPincode(),ElementLocators_Rynair.txt_PostalCode);
  			    
  			    }
              
              
              PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
            
              
              
              
	}
	
    
	@When("^cancel alert popup$")
	
	public void cancel_alert_popup() throws Throwable {
	
		
		
		PageFactoryResuableComp.AlertDismiss();
	}
	
	
	
    @When("^scroll down the web page$")
	
	public void scroll_down_the_web() throws Throwable {
	
    	ScreenshotName = "scroll down the web page";
		
		PageFactoryResuableComp.WebScrollDown();
		
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
	
    }
    
    
    
    @When("^handle cookie popup \"([^\"]*)\"$")
	
	public void handle_cookie_pop_up(String CookieElementID) throws Throwable {
	
    	ScreenshotName = "handle cookie popup  "+"  "+CookieElementID;
		
    	if(CookieElementID.equalsIgnoreCase("CookiePopup")) {
    		
    		PageFactoryResuableComp.WindowHandlesforPopup(ElementLocators_Rynair.CookiePopup);
    	
    		}
	
    	PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
    
    
    }
    
    
    
    @When("^put scroll to element \"([^\"]*)\"$")
	
	public void scroll_down_the_web(String ToElement) throws Throwable {
    	
    	ScreenshotName = "put scroll to element "+"  "+ToElement;
	
		if(ToElement.equalsIgnoreCase("PaymentbycardOption")) {
		
		PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.PaymentbycardOption);
	
		}
		
		
		if(ToElement.equalsIgnoreCase("InsuredOption")) {
			
			PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.InsuredOption);
		
			}
		
		
		
          if(ToElement.equalsIgnoreCase("ErrorMessage")) {
			
			PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.ErrorMessage);
		
			}
          
          
          if(ToElement.equalsIgnoreCase("InsuredLabel")) {
  			
  			PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.InsuredLabel);
  		
  			}
          
          if(ToElement.equalsIgnoreCase("DummyScroll")) {
    			
    			PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.DummyScroll);
    		
    			}
          
          
          if(ToElement.equalsIgnoreCase("txt_CardNumber")) {
  			
  			PageFactoryResuableComp.WebScrolltoElement(ElementLocators_Rynair.txt_CardNumber);
  		
  			}
      
    
    
          PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
    
    
    
    }
	
	
	
	
  
	
  //@Then("^mouse move and click an element \\\"([^\\\"]*)\\\"$")
	@Then("^mouse move and click an element \"([^\"]*)\"$")
	public void mouse_move_and_click_an_element(String myelement) throws Throwable {
		
		ScreenshotName = "mouse move and click an element "+"  "+myelement;
	
		
		if(myelement.equalsIgnoreCase("ChooseDatebtn")) {
		PageFactoryResuableComp.MousehoverAndClick(ElementLocators_Rynair.ChooseDatebtn);
	
  }
		
		
		if(myelement.equalsIgnoreCase("ListItemMr")) {
			PageFactoryResuableComp.MousehoverAndClick(ElementLocators_Rynair.ListItemMr);
		
	  }
		
		if(myelement.equalsIgnoreCase("ListItemMrs")) {
			PageFactoryResuableComp.MousehoverAndClick(ElementLocators_Rynair.ListItemMrs);
		
	  }
		
		if(myelement.equalsIgnoreCase("ListItemMs")) {
			PageFactoryResuableComp.MousehoverAndClick(ElementLocators_Rynair.ListItemMs);
		
	  }
		
		
		
		if(myelement.equalsIgnoreCase("CookiePopup")) {
			PageFactoryResuableComp.MousehoverAndClick(ElementLocators_Rynair.CookiePopup);
		
	  }
  
  
		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");
  
  }
  
  
  
  
  @Then("^move mouse to an element \"([^\"]*)\"$")
	
	public void move_mouse_to_element(String myelement) throws Throwable {
	  
	  
	  ScreenshotName = "move mouse to an element "+"  "+myelement;
	
		
				
		if(myelement.equalsIgnoreCase("CookiePopup")) {
			PageFactoryResuableComp.Mousehover(ElementLocators_Rynair.CookiePopup);
		
	  }
		
		
		if(myelement.equalsIgnoreCase("ListItemMr")) {
			PageFactoryResuableComp.Mousehover(ElementLocators_Rynair.ListItemMr);
		
	  }


		PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");

}
  
  
  
  
  @Then("^slow entering the data in the field \"([^\"]*)\"$")
	
	public void slow_entering_the_data(String Myslowelement) throws Throwable {
	
	  ScreenshotName = "slow entering the data in the field "+"  "+Myslowelement;
				
	       if(Myslowelement.equalsIgnoreCase("ToTravel")) {
			
		    PageFactoryResuableComp.slowEntering(ElementLocators_Rynair.ToTravel,TDH.getToTravel());
		    
		     } 
	       
	       
	       if(Myslowelement.equalsIgnoreCase("txt_cardExpiryDate")) {
				
			    PageFactoryResuableComp.slowEntering(ElementLocators_Rynair.txt_cardExpiryDate,TDH.getCardExpiryDate());
			    
			     } 
			
		
		
	       PageFactoryResuableComp.takeSnapShot(PageFactoryResuableComp.configFileReader()+ScreenshotName+".png");




}
  
  
  @Then("^close the browser$")
	
	public void close_the_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactoryResuableComp.close();
	}
  
  
	
	/**
	@When("^I want to send data to searchbox$")
	
	public void i_want_to_send_data_to_searchbox() throws Throwable {
	
		
		
		PageFactoryResuableComp.SendValue("Poland",ElementLocators_Toolsqa.SearchBox);
	}

	
	@Then("^I click on search button$")
	
	public void i_click_on_search_button() throws Throwable {
	    
		PageFactoryResuableComp.clickMethod(ElementLocators_Toolsqa.SearchBtn);
	}
	
	
	@Then("^I close the browser$")
	
	public void i_close_the_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactoryResuableComp.close();
	}

  **/
	
	/**
	
	// Wait for Page load Time
	@Given("^wait for page load time \"([^\"]*)\"$")
	@When("^wait for page load time \"([^\"]*)\"$")
	@Then("^wait for page load time \"([^\"]*)\"$")
	public void wait_for_page_load_time(String loadtime) throws Throwable {
	    
		int PageLoadtime = Integer.parseInt(loadtime);
		PageFactoryResuableComp.WaitForPageLoad(PageLoadtime);
	}
	

	@Given("I click menu option \"([^\"]*)\"$")
	@When("^I click menu option \"([^\"]*)\"$")
	@Then("^I click menu option \"([^\"]*)\"$")
	public void I_click_menu_option(String MenuOption) throws Throwable {
		
		    
		
		if(MenuOption.equalsIgnoreCase("LoginMenuOption")) {
		
		PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.LoginMenuOption);
	    
	       } 
	
	
	
	
	
	
	
	
	}
	
	
	
	
	@Given("^make click button \"([^\"]*)\"$")
	@When("^make click button \"([^\"]*)\"$")
	@Then("^make click button \"([^\"]*)\"$")
	public void make_click_button(String UserButton) throws Throwable {
		
		    
		
		if(UserButton.equalsIgnoreCase("Btn_Login")) {
		
		PageFactoryResuableComp.clickMethod(ElementLocators_Rynair.Btn_Login);
	    
	     } 
	
	
	
	
	
	
	
	
	}
	
	
	
	
	
	
	@Given("^enter data in the field \"([^\"]*)\"$")
	@When("^enter data in the field \"([^\"]*)\"$")
	@Then("^enter data in the field \"([^\"]*)\"$")
	public void enter_data_in_the_field(String FieldData) throws Throwable {
		
		    
		
		if(FieldData.equalsIgnoreCase("LoginField")) {
		
	    PageFactoryResuableComp.SendValue(TDH.getLoginId(),ElementLocators_Rynair.LoginField);
	    
	     } 
		
		
		if(FieldData.equalsIgnoreCase("PasswordField")) {
			
		    PageFactoryResuableComp.SendValue(TDH.getLoginId(),ElementLocators_Rynair.PasswordField);
		    
		    } 
	
	
	
	
	
	
	
	
	}

**/

   


}
