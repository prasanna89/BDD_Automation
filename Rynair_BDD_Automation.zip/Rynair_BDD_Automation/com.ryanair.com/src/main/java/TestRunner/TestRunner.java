package TestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
//import cucumber.api.junit.*;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\test\\java\\Features",tags="@01,@02,@03,@04,@05,@06,@07", //the path of the feature files
		glue={"StepDefinitions"},plugin = {"pretty","html:target/test-output/cucumber-reports","json:target/test-output/cucumberReports.json","junit:target/test-output/cucumberJunitReports.xml"}//the path of the step definition files
		//format= {"pretty","html:test-outout", "json:json_output/cucumber.json", "junit:junit_xml/cucumber.xml"}, //to generate different types of reporting
		//monochrome = true, //display the console output in a proper readable format
		//strict = true, //it will check if any step is not defined in step definition file
		//dryRun = false //to check the mapping is proper between feature file and step def file
		//tags = {"~@SmokeTest" , "~@RegressionTest", "~@End2End"}			
		)


public class TestRunner {

}
